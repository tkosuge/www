#!/bin/sh
JAVA_PRIMARY_VERSION=`java -version 2>&1 | grep "java version" | awk -F\" '{print $2}' | awk -F\. '{print $1}' 2>&1`
VM_OPTS_ADD_OPENS=""
if [ ${JAVA_PRIMARY_VERSION} -eq 1 ]; then
    # jdk 8
    VM_OPTS_ADD_OPENS=""
elif [ ${JAVA_PRIMARY_VERSION} -ge 9 ]; then
    # jdk 9 or lator
    VM_OPTS_ADD_OPENS="--add-opens=java.base/java.lang=ALL-UNNAMED"
else
    echo "Invalid java version"
    exit 1
fi
java ${VM_OPTS_ADD_OPENS} -Xmx1024M -Djsse.enableSNIExtension=false -Djavax.xml.parsers.DocumentBuilderFactory=com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl -Djavax.xml.parsers.SAXParserFactory=com.sun.org.apache.xerces.internal.jaxp.SAXParserFactoryImpl -jar agd.jar
