#!/bin/bash
if [ "${AGD_PROXY_USER}" != "" -o "${AGD_PROXY_PASSWORD}" != "" ] ; then
    printf "overwrite Proxy server user name and password.\n"
fi
read -p "Proxy server user name : " proxyUser
export AGD_PROXY_USER="${proxyUser}"
read -sp "Proxy server password  : " proxyPassword 
echo ""
export AGD_PROXY_PASSWORD="${proxyPassword}"
if [ "${AGD_PROXY_USER}" = "" ]; then
    printf "WARNING: Proxy server user name is empty.\n"
fi
if [ "${AGD_PROXY_PASSWORD}" = "" ]; then
    printf "WARNING: Proxy server password is empty.\n"
fi
