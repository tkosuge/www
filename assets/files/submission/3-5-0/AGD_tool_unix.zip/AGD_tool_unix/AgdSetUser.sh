#!/bin/bash
if [ "${AGD_USER}" != "" -o "${AGD_PASSWORD}" != "" ] ; then
    printf "overwrite AGD login user name and password.\n"
fi
read -p "AGD login user name : " loginUser
export AGD_USER="${loginUser}"
read -sp "AGD Login password  : " loginPassword
echo ""
export AGD_PASSWORD="${loginPassword}"
if [ "${AGD_USER}" = "" ]; then
    printf "WARNING: AGD login user name is empty.\n"
fi
if [ "${AGD_PASSWORD}" = "" ]; then
    printf "WARNING: AGD login password is empty.\n"
fi
